extends CharacterBody2D
@onready var stamina_bar: TextureProgressBar = $"../Main_GUI/Stamina_Bar"
@onready var sun_timer: Timer = $Sun_Timer
@onready var low_stamina_timer: Timer = $Low_Stamina_Timer
@onready var item_water: StaticBody2D = $"../Item_Water"
@onready var main: Node2D = $".."


var speed = 3
const JUMP_VELOCITY = -300
var health_max = 100
var health_current
var waterpickup = false
signal health_changed
signal game_reset
var player_state

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	stamina_bar.sprint_start.connect(sprint_start)
	stamina_bar.sprint_end.connect(sprint_end)
	stamina_bar.low_stamina.connect(low_stamina)
	stamina_bar.high_stamina.connect(high_stamina)
	main.level_completed.connect(level_completed)
	health_current = health_max
	sun_timer.wait_time = 0.05
	sun_timer.paused = true
	low_stamina_timer.paused = true
	
	position = Vector2(80, 472)


	
func sprint_start():
	speed = 5
	$AnimatedSprite2D.animation = "Sprint"
	
func sprint_end():
	speed = 3
	$AnimatedSprite2D.animation = "Running"
	
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _physics_process(delta: float) -> void:
	var h_velocity = Vector2.ZERO
	
	if not is_on_floor():
		velocity += get_gravity() * delta
		
	if Input.is_action_pressed("move_left"):
		h_velocity.x = -1
		$AnimatedSprite2D.flip_h = true
	if Input.is_action_pressed("move_right"):
		h_velocity.x = 1
		$AnimatedSprite2D.flip_h = false
		
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y += JUMP_VELOCITY
	
	#Change player speed if sprint is pressed.
	#Change Animation if sprint is pressed and idle if not moving.
	if h_velocity.x != 0 or velocity.y != 0:
		if velocity.y != 0:
			$AnimatedSprite2D.animation = "Jumping"
		elif velocity.y == 0 and h_velocity.x != 0:
			if speed == 10:
				$AnimatedSprite2D.animation = "Sprint"
			else:
				$AnimatedSprite2D.animation = "Running"
				
		$AnimatedSprite2D.play()
	else:
		$AnimatedSprite2D.animation = "Idle"
		$AnimatedSprite2D.stop()
		
	#change the players velocity based on current speed.
	position += h_velocity * speed 
	
	if position.y > 800 or health_current < 1:
		reset()
		
	move_and_slide()
	
	if waterpickup == true:
		var health_change = 50
		if (health_current + health_change) > health_max:
			health_current = health_max
		else:
			health_current += health_change
		waterpickup = false
		health_changed.emit()
	
func reset():
	get_tree().reload_current_scene()

func level_completed():
	if health_current > 50:
		player_state = "Very Healthy, No Skin Damage"
	elif health_current > 40:
		player_state = "Mostly Healthy, Minor Skin Damage"
	elif health_current > 30:
		player_state = "Mostly Healthy, Temporary Skin Damage"
	else:
		player_state = "UnHealhy, Permenant Skin Burns"

func _on_sun_area_body_entered(body: CharacterBody2D) -> void:
	sun_timer.paused = false
	
func _on_sun_area_body_exited(body: CharacterBody2D) -> void:
	sun_timer.paused = true
	
func _on_sun_timer_timeout() -> void:
	health_current -= 0.7
	health_changed.emit()
	
func low_stamina():
	low_stamina_timer.paused = false
func high_stamina():
	low_stamina_timer.paused = true
	
func _on_low_stamina_timer_timeout() -> void:
	health_current -= 0.4
	health_changed.emit()
	
