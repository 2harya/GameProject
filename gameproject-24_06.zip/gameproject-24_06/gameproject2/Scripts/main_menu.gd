extends Control
@onready var buttons_container: VBoxContainer = $Buttons_Container
@onready var options_panel: Panel = $Options_Panel
@onready var levels_panel: Panel = $Levels_Panel


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	options_panel.visible = false
	levels_panel.visible = false


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_button_start_pressed() -> void:
	get_tree().change_scene_to_file("res://Scenes/tutorial.tscn")

func _on_button_exit_pressed() -> void:
	get_tree().change_scene_to_file("res://Scenes/main.tscn")

func _on_button_options_pressed() -> void:
	options_panel.visible = true

func _on_button_levels_pressed() -> void:
	levels_panel.visible = true
