extends StaticBody2D
signal item_selected
@onready var player: CharacterBody2D = $"../Player"

var pickup_range = false
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	scale = Vector2(0.2,0.2)
	pickup_range = false


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if pickup_range == true:
		if Input.is_action_just_pressed("pick_up"):
			item_selected.emit()
			player.waterpickup = true
			queue_free()
	
			
func _on_pickup_area_body_entered(body: CharacterBody2D) -> void:
	pickup_range = true
func _on_pickup_area_body_exited(body: CharacterBody2D) -> void:
	pickup_range = false
	
	
