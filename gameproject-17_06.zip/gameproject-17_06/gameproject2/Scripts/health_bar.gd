extends TextureProgressBar
@onready var player: CharacterBody2D = $"../../Player"


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	max_value = player.health_max
	value = player.health_current
	player.health_changed.connect(update)
	
func update():
	value = player.health_current * 100 / player.health_max
	
