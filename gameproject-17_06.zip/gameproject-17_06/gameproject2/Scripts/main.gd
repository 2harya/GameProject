extends Node2D
@onready var player: CharacterBody2D = $Player
@onready var water: StaticBody2D = $Item_Water
@onready var exit_panel: Panel = $Main_GUI/Panel
@onready var options_panel: Panel = $Main_GUI/Options_Panel

var item_water = load("res://Scenes/item_water.tscn")
signal level_completed

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	exit_panel.visible = false
	
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
	
	

func _finished_area_entered(body: CharacterBody2D) -> void:
	level_completed.emit()
	print("level completed")
	get_tree().change_scene_to_file("res://Scenes/gui_end_screen.tscn")


func _on_button_menu_pressed() -> void:
	exit_panel.visible = true
	options_panel.visible = false

func _on_button_return_to_menu_pressed() -> void:
	get_tree().change_scene_to_file("res://Scenes/main_menu.tscn")


func _on_button_popup_close_pressed() -> void:
	exit_panel.visible = false

func _on_button_options_pressed() -> void:
	options_panel.visible = true
	exit_panel.visible = false
