extends Node2D
@onready var player: CharacterBody2D = $Player
@onready var water: StaticBody2D = $Item_Water

var item_water = load("res://Scenes/item_water.tscn")
signal level_completed

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass
	
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
	
	

func _finished_area_entered(body: CharacterBody2D) -> void:
	level_completed.emit()
	print("level completed")
	get_tree().change_scene_to_file("res://Scenes/gui_end_screen.tscn")
