extends Control
@onready var info_label: Label = $Info_Label
@onready var levels_panel: Panel = $Levels_Panel


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	levels_panel.visible = false

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_button_replay_pressed() -> void:
	get_tree().change_scene_to_file("res://Scenes/main.tscn")


func _on_button_exit_pressed() -> void:
	get_tree().quit()


func _on_button_main_menu_pressed() -> void:
	get_tree().change_scene_to_file("res://Scenes/main_menu.tscn")


func _on_button_levels_pressed() -> void:
	levels_panel.visible = true
