extends TextureProgressBar
@onready var player: CharacterBody2D = $"../../Player"
@onready var timer: Timer = $Timer

signal sprint_start
signal sprint_end
signal low_stamina
signal high_stamina

var sprinting
var max_stamina = 500
var update_time = 0.01
var min_sprint
const min_sprint_amount = 0.2
const low_stamina_amount = 0.4
var increase_rate = 1
var decrease_rate = 2


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	player.game_reset.connect(reset_bar)
	
	max_value = max_stamina
	value = max_value
	timer.wait_time = update_time
	min_sprint = max_value * min_sprint_amount
	texture_progress = preload("res://Sprites/Stamina_Front.png")
	


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if Input.is_action_just_pressed("sprint") and value > min_sprint:
		if value > 0:
			sprint_start.emit()
			sprinting = true
			timer.paused = false
			
		else:
			sprint_end.emit()
			sprinting = false
			timer.paused = true
			
	if Input.is_action_pressed("sprint") == false:
		sprint_end.emit()
		sprinting = false
		if value != max_value:
			timer.paused = false
		else:
			timer.paused = true
			
	if (value)/max_value < min_sprint_amount:
		texture_progress = preload("res://Sprites/Stamina_Progress3.png")
	elif (value)/max_value < low_stamina_amount:
		texture_progress = preload("res://Sprites/Low_Stamina_Progress.png")
	else:
		texture_progress = preload("res://Sprites/Stamina_Progress2.png")
		
	if (value)/max_value < low_stamina_amount:
		low_stamina.emit()
	else:
		high_stamina.emit()
		
func _on_timer_timeout() -> void:
	if sprinting == false:
		value += increase_rate
	else:
		value -= decrease_rate
		
func reset_bar():
	value = max_value
