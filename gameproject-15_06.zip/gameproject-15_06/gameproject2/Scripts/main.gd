extends Node2D
@onready var player: CharacterBody2D = $Player
@onready var water: StaticBody2D = $Item_Water

var item_water = load("res://Scenes/item_water.tscn")
signal level_completed

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	player.game_reset.connect(reset)
	
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
	
func reset():
	var water_instance = item_water.instantiate()
	water_instance.position = Vector2(1088, 512)
	add_child(water_instance)
	

func _finished_area_entered(body: CharacterBody2D) -> void:
	level_completed.emit()
	print("level completed")
